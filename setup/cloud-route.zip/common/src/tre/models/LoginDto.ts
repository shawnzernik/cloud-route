export interface LoginDto {
    emailAddress: string;
    password: string;
}
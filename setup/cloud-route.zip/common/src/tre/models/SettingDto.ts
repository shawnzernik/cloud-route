export interface SettingDto {
    guid: string;
    key: string;
    value: string;
}

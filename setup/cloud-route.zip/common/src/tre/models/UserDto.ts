export interface UserDto {
    guid: string;
    displayName: string;
    emailAddress: string;
    smsPhone: string;
}

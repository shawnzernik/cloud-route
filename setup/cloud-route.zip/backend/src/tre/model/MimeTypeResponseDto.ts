export interface MimeTypeResponseDto {
    mimetype: string;
    contents: Uint8Array;
}
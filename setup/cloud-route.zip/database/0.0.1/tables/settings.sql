CREATE TABLE "settings" (
	"guid" UUID PRIMARY KEY,	
    "key" VARCHAR(100) NOT NULL,
	"value" TEXT NOT NULL
);

INSERT INTO list_filters (guid,lists_guid,"label",sql_column,sql_type,options_sql,default_compare,default_value) VALUES
	 ('86c5286c-8a54-4f81-9b80-ee46a8e53871','220331be-8d3c-4969-b1f2-4bc578038003','Administrator','Administrator','varchar','','c',''),
	 ('94b9c7c7-086f-4f5b-a01b-cae386671b77','220331be-8d3c-4969-b1f2-4bc578038003','Display','Display','varchar','','c',''),
	 ('5c842130-3fe3-43cd-b09f-bf66342f8fc3','24ebb2fe-b803-4e6d-8516-155ab0e910ef','Title','Title','varchar','','c',''),
	 ('974e58e1-c0cf-4757-a2ab-addcfc04d948','24ebb2fe-b803-4e6d-8516-155ab0e910ef','Edit URL','Edit URL','varchar','','c',''),
	 ('a1f38930-8eca-4feb-a24e-d050ef93d63f','24ebb2fe-b803-4e6d-8516-155ab0e910ef','URL Key','URL Key','varchar','','c',''),
	 ('32d681f3-3bf1-4e4d-b3e4-14aa19327364','59f75ec4-ec64-4b18-906c-8275c9ac7a43','Display','Display','varchar','','c',''),
	 ('868b0ef7-68d7-452f-8cb6-bf579b1f4a32','59f75ec4-ec64-4b18-906c-8275c9ac7a43','Icon','Icon','varchar','','c',''),
	 ('95435bbc-4ff8-4e80-80cd-8453f7131b59','59f75ec4-ec64-4b18-906c-8275c9ac7a43','URL','URL','varchar','','c',''),
	 ('543fd79d-e45e-4817-b098-82a7befdf226','3050d3ae-d26b-4341-a7a2-e75ba40de46d','Display','Display','varchar','','c',''),
	 ('78ed42d9-b0e5-4994-aa47-6ef1b8d000dc','51ec361f-8a5c-46b2-8c51-68e8516b046f','Value','Value','varchar','','c','');
INSERT INTO list_filters (guid,lists_guid,"label",sql_column,sql_type,options_sql,default_compare,default_value) VALUES
	 ('a99061c0-c5f0-4250-808b-6fa83ba486b9','51ec361f-8a5c-46b2-8c51-68e8516b046f','Kay','Kay','varchar','','c',''),
	 ('157e9fa0-4e3a-45bc-a200-9c9636cff915','ac5ee873-c05f-4c64-8ec6-f426f9cd6226','Name','Name','varchar','','c',''),
	 ('9b8ec95a-140b-4fea-af03-42d5a0af59cc','ac5ee873-c05f-4c64-8ec6-f426f9cd6226','Phone','Phone','varchar','','c',''),
	 ('51e6a256-1519-45bc-bb00-64eb4762149c','ac5ee873-c05f-4c64-8ec6-f426f9cd6226','Email','Email','varchar','','c','');

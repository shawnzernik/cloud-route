import { Dictionary } from "./Dictionary";

export interface ConfigDto extends Dictionary<string[]> { }
import { CSSProperties } from "react";
import { Theme } from "./Theme";

export const CheckboxTheme: CSSProperties = {
};

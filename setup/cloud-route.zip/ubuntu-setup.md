# Ubuntu Setup

Install Ubuntu using the minimal and include SSH.  If using a VM, make sure to set the network to bridge.

Install the following software:

```
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.0/install.sh | bash
nvm install 20

node -v
npm -v

sudo apt install postgresql vim unzip zip
```

Edit `/etc/postgresql/16/main/postgresql.conf` file to uncomment and change "listen_addresses" to "*".  Restart Postgresql:
Edit `/etc/postgresql/16/main/pg_hba.conf` file an add the following line:

```
hostssl all all samenet scram-sha-256
```

This will allow SSL connections for all databases from all users on the same network as the server using SCRAM-SHA-256 hashing.  Save and restart PostgreSQL.

```
sudo systemctl restart postgres
```

Now you should be able to connect to the PostgreSQL server:

```
sudo -u postgres psql postgres
ALTER USER postgres with encrypted password 'postgres';
exit
psql --username postgres --host localhost
```

Once you login, you know it's working.

You can copy the file to your server using SCP:

```
./clean.sh
zip -r ../cloud-route.zip . --exclude './.git/*'
scp ../cloud-route.zip administrator@server:~/
```

Log into 'server' and run the following:

```
ssh server
cd /opt
sudo mkdir cloud-route
cd cloud-route
unzip ~/cloud-route.zip
./setup



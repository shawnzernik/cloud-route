export interface ResponseDto<T> {
    data?: T;
    error?: string;
}
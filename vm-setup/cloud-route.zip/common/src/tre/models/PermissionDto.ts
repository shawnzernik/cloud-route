export interface PermissionDto {
    guid: string;
    groupsGuid: string;
    securablesGuid: string;
    isAllowed: boolean;
}
export interface GroupDto {
    guid: string;
    displayName: string;
    isAdministrator: boolean;
}

export interface MembershipDto {
    guid: string;
    groupsGuid: string;
    usersGuid: string;
    isIncluded: boolean;
}
export interface ContentMimeTypeDto {
    extension: string;
    description: string;
    mimetype: string;
    encode: boolean;
}
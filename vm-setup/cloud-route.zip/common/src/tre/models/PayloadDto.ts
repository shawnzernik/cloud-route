export interface PayloadDto {
    guid: string;
    content: string;
}
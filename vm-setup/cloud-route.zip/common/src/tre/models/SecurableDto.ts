export interface SecurableDto {
    guid: string;
    displayName: string;
}
INSERT INTO "securables" ("guid", "display_name") VALUES
('dbbc17b4-b389-4371-b5c0-5715176f3b81', 'Content:Delete'),
('72c5c616-2ca7-4459-b176-d2f10d77e5d7', 'Content:List'),
('0f191539-cb06-4c52-aaf6-f7556b7a83d6', 'Content:Read'),
('5e249e0d-9520-4a31-b019-6e6e01e9cc62', 'Content:Save'),
('b2589b39-0e77-47a3-9c41-a46b7b08aa94', 'Content:Public'),

('b8fd8b77-3f68-4f80-b1e9-0b3b54bf15de', 'Payload:Delete'),
('c5f85fba-9404-4d83-a2c5-567a0546596c', 'Payload:List'),
('e1111f4e-8b6e-4655-8735-86d7b0c2181a', 'Payload:Read'),
('7e4945ff-d89d-4b7d-bd40-d6678fdd282d', 'Payload:Save');

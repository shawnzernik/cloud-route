INSERT INTO "securables" ("guid", "display_name") VALUES
('ec1942c4-6ffc-4e16-a17f-7e560fc6b98f', 'OpenVpn:Apply'),
('c4618970-5376-43d7-b38a-5603f55c221e', 'OpenVpn:Cert:List'),
('0e362ade-cbe7-49e6-95d9-c77222b85b02', 'OpenVpn:Create:CA'),
('b79f3c92-afe1-4253-b465-3f01f28dfd16', 'OpenVpn:Create:Client'),

('4e3d6d80-5ad3-4e84-9360-3ee92d7b5a28', 'System:Top'),
('ba197e91-f684-4649-889d-dc1073a423f7', 'System:Proc:Net:Dev'),
('369e2cb6-8bad-42b8-884d-57513c0c7e5b', 'System:Etc:Netplan'),

('0453e627-0f23-49c4-b994-91efa5eab78e', 'Adapter:Delete'),
('e5dd96ef-5bb9-421b-a7aa-02be43343c6c', 'Adapter:List'),
('57eeea32-ca91-4be8-bada-90c3b75dcbd7', 'Adapter:Read'),
('7b1ae4a5-1ecb-4760-91e0-1ef7565f5f85', 'Adapter:Save');
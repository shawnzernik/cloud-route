import { CSSProperties } from "react";

export const MarkdownTheme: CSSProperties = {
};